<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$halamanbebas = [
    'login.php',
    'logout.php',
    'buat_admin.php'
];

$halamansaatini = basename($_SERVER['PHP_SELF'] ?? '');

if (
    !in_array($halamansaatini, $halamanbebas, true) &&
    empty($_SESSION['user_id'])
) {
    header('Location: login.php');
    exit;
}