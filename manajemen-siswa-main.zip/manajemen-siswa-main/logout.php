<?php

require __DIR__ . '/config/auth.php';

$_SESSION = [];


header('Location: login.php');
exit;