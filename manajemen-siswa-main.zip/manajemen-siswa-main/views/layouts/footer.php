<footer class="footer">

    <div class="footer-content">
        <p class="footer-title">
            SMK MIFTAHUL KHAIR
        </p>

        <p class="footer-text">
            &copy; <?= date('Y') ?> Manajemen Siswa.
            Semua hak dilindungi.
        </p>

        <p class="footer-subtitle">
            Sistem Informasi Manajemen Siswa
        </p>
    </div>

</footer>

</body>
</html>