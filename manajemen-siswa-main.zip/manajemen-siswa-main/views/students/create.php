<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    .form-page {
        max-width: 800px;
        margin: 20px auto;
        animation: fadeIn 0.5s ease;
    }

    .form-title {
        background: linear-gradient(135deg, #065f46, #10b981);
        color: white;
        padding: 25px;
        border-radius: 14px;
        margin-bottom: 25px;
        box-shadow: 0 5px 15px rgba(5,150,105,0.2);
    }

    .form-title h1 {
        margin: 0 0 8px;
        font-size: 27px;
    }

    .form-title p {
        margin: 0;
        color: #d1fae5;
        font-size: 14px;
    }

    .form-container {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.07);
        border: 1px solid #d1fae5;
    }

    .form-container p {
        margin-bottom: 20px;
    }

    .form-container label {
        display: inline-block;
        color: #334155;
        font-weight: 600;
        margin-bottom: 8px;
        font-size: 14px;
    }

    .form-container input[type="text"],
    .form-container input[type="date"] {
        width: 100%;
        padding: 12px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        background: #f8fafc;
        font-size: 14px;
        outline: none;
        transition: 0.3s;
    }

    .form-container input:focus {
        border-color: #10b981;
        background: white;
        box-shadow: 0 0 0 3px rgba(16,185,129,0.12);
    }

    .gender-option {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        background: #ecfdf5;
        border: 1px solid #bbf7d0;
        padding: 10px 15px;
        border-radius: 8px;
        margin-right: 10px;
        cursor: pointer;
    }

    .gender-option input {
        accent-color: #059669;
    }

    .gender-option label {
        margin: 0;
        cursor: pointer;
    }

    .btn-save {
        background: linear-gradient(135deg, #059669, #047857);
        color: white;
        border: none;
        padding: 12px 22px;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }

    .btn-save:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 12px rgba(5,150,105,0.25);
    }

    .btn-cancel {
        display: inline-block;
        background: #e2e8f0;
        color: #334155;
        padding: 12px 22px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: bold;
        margin-left: 8px;
        transition: 0.3s;
    }

    .btn-cancel:hover {
        background: #cbd5e1;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(12px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media(max-width: 600px) {
        .form-container {
            padding: 20px;
        }

        .form-title h1 {
            font-size: 23px;
        }
    }
</style>

<div class="form-page">

    <div class="form-title">
        <h1>Tambah Peserta</h1>
        <p>Formulir Penambahan Data Siswa SMK Miftahul Khair</p>
    </div>

    <div class="form-container">

        <form action="create.php" method="POST">

            <p>
                <label>NIS</label><br>
                <input
                    type="text"
                    name="nis"
                    placeholder="Masukkan NIS siswa"
                    required
                >
            </p>

            <p>
                <label>Nama Lengkap</label><br>
                <input
                    type="text"
                    name="name"
                    placeholder="Masukkan nama lengkap"
                    required
                >
            </p>

            <p>
                <label>Tempat Lahir</label><br>
                <input
                    type="text"
                    name="birth_place"
                    placeholder="Masukkan tempat lahir"
                >
            </p>

            <p>
                <label>Tanggal Lahir</label><br>
                <input
                    type="date"
                    name="birth_date"
                >
            </p>

            <p>
                <label>Jenis Kelamin</label><br><br>

                <label class="gender-option">
                    <input
                        type="radio"
                        name="gender"
                        value="L"
                        required
                    >
                    👨 Lakek lakek
                </label>

                <label class="gender-option">
                    <input
                        type="radio"
                        name="gender"
                        value="P"
                    >
                    👩 binik binik
                </label>
            </p>

            <p>
                <label>Kelas</label><br>
                <input
                    type="text"
                    name="class_name"
                    placeholder="Contoh: XII RPL"
                    required
                >
            </p>

            <p>
                <label>Jurusan</label><br>
                <input
                    type="text"
                    name="major"
                    placeholder="Masukkan jurusan"
                    required
                >
            </p>

            <p>
                <button type="submit" class="btn-save">
                    ✓ Simpan Data oy!!
                </button>

                <a href="index.php" class="btn-cancel">
                    ← Batal
                </a>
            </p>

        </form>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
```