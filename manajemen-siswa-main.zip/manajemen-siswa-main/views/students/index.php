<?php require 'views/layouts/header.php'; ?>

<style>
    body {
        background: linear-gradient(135deg, #dcfce7, #bbf7d0);
    }

    .page-title {
        color: #166534;
        font-size: 30px;
        font-weight: bold;
        margin-bottom: 8px;
    }

    .page-subtitle {
        color: #15803d;
        margin-bottom: 25px;
    }

    .alert-success {
        background: #dcfce7;
        color: #166534;
        border-left: 5px solid #22c55e;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .btn-add {
        display: inline-block;
        background: linear-gradient(135deg, #22c55e, #15803d);
        color: white;
        padding: 12px 20px;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        margin-bottom: 20px;
        box-shadow: 0 4px 10px rgba(34,197,94,0.3);
        transition: 0.3s;
    }

    .btn-add:hover {
        background: #166534;
        transform: translateY(-2px);
    }

    .table-container {
        background: white;
        padding: 15px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        overflow-x: auto;
    }

    .student-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 650px;
    }

    .student-table th {
        background: linear-gradient(135deg, #166534, #22c55e);
        color: white;
        padding: 15px;
        text-align: center;
    }

    .student-table td {
        padding: 14px;
        text-align: center;
        border-bottom: 1px solid #22c55e;
        color: #334155;
    }

    .student-table tbody tr:hover {
        background: #dcfce7;
    }

    .student-table tbody tr:nth-child(even) {
        background-color: #f0fdf4;
    }

    .action-btn {
        display: inline-block;
        padding: 7px 12px;
        border-radius: 6px;
        text-decoration: none;
        color: white;
        font-size: 13px;
        margin: 2px;
        transition: 0.2s;
    }

    .btn-detail {
        background: #0ea5e9;
    }

    .btn-edit {
        background: #f59e0b;
    }

    .btn-delete {
        background: #ef4444;
    }

    .action-btn:hover {
        opacity: 0.8;
        transform: translateY(-2px);
    }

    .empty-data {
        text-align: center;
        padding: 25px;
        color: #22c55e;
    }
</style>

<h1 class="page-title">Daftar Siswa</h1>

<p class="page-subtitle">
    Sistem Informasi Manajemen Siswa SMK Miftahul Khair
</p>

<?php if (!empty($success)): ?>
    <div class="alert-success">
        ✓ <?= htmlspecialchars($success) ?>
    </div>
<?php endif; ?>

<a href="create.php" class="btn-add">
    + Tambah Siswa
</a>

<div class="table-container">
    <table class="student-table">
        <thead>
            <tr>
                <th>No</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Kelas</th>
                <th>Jurusan</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php if (!empty($students)): ?>

                <?php foreach ($students as $index => $student): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($student['nis']) ?></td>
                        <td><?= htmlspecialchars($student['name']) ?></td>
                        <td><?= htmlspecialchars($student['gender']) ?></td>
                        <td><?= htmlspecialchars($student['class_name']) ?></td>
                        <td><?= htmlspecialchars($student['major']) ?></td>

                        <td>
                            <a class="action-btn btn-detail"
                               href="student.php?id=<?= (int)$student['id'] ?>">
                                Detail
                            </a>

                            <a class="action-btn btn-edit"
                               href="edit.php?id=<?= (int)$student['id'] ?>">
                                Edit
                            </a>

                            <a class="action-btn btn-delete"
                               href="delete.php?id=<?= (int)$student['id'] ?>"
                               onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')">
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="7" class="empty-data">
                        Belum ada data siswa.
                    </td>
                </tr>

            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require 'views/layouts/footer.php'; ?>
```