<?php

class StudentController
{
    private Student $studentModel;

    public function __construct(Student $studentModel)
    {
        $this->studentModel = $studentModel;
    }

    public function index()
    {
        $students = $this->studentModel->getAll();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);

        require __DIR__ . '/../views/students/index.php';
    }

    public function show($id)
    {
        $student = $this->studentModel->find($id);

        if (!$student) {
            echo "Data siswa tidak ditemukan.";
            exit;
        }
        if (session_status() === PHP_SESSION_NONE) {
            session_start();

        }
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);


        require __DIR__ . '/../views/students/show.php';
    }

    public function create()
    {
        require __DIR__ . '/../views/students/create.php';
    }

    public function store()
    {
        $data = [
            'nis'         => $_POST['nis'] ?? '',
            'name'        => $_POST['name'] ?? '',
            'gender'      => $_POST['gender'] ?? '',
            'class_name'  => $_POST['class_name'] ?? '',
            'major'       => $_POST['major'] ?? '',
            'birth_place' => $_POST['birth_place'] ?? '',
            'birth_date'  => $_POST['birth_date'] ?? '',
        ];

        $this->studentModel->create($data);

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['success']='Data siswa berhasil ditambahkan.';

        header('Location: index.php');
        exit;
    }

    public function edit($id)
    {
        $student = $this->studentModel->find($id);

        if (!$student) {
            echo "Data siswa tidak ditemukan.";
            exit;
        }

        require __DIR__ . '/../views/students/edit.php';
    }

    public function update($id)
    {
        $data = [
            'nis'         => $_POST['nis'] ?? '',
            'name'        => $_POST['name'] ?? '',
            'gender'      => $_POST['gender'] ?? '',
            'class_name'  => $_POST['class_name'] ?? '',
            'major'       => $_POST['major'] ?? '',
            'birth_place' => $_POST['birth_place'] ?? '',
            'birth_date'  => $_POST['birth_date'] ?? '',
        ];

        $this->studentModel->update($id, $data);

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['success']='Data siswa berhasil diupdate.';

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['success'] = 'Data siswa berhasil diperbarui.';

        header('Location: index.php');
        exit;
    }

    public function delete($id)
    {
        $this->studentModel->delete($id);

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['success'] = 'Data siswa berhasil dihapus.';

        header('Location: index.php');
        exit;
    }
}