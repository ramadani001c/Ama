
<?php
require __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare(
        'SELECT * FROM Users WHERE Username = :username LIMIT 1'
    );

    $stmt->execute([
        'username' => $username
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {

        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['Username'];

        header('Location: index.php');
        exit;

    } else {
        $error = 'Username atau password salah!';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login - Manajemen Siswa</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;

    background:
        radial-gradient(circle at top left, #34d399, transparent 35%),
        linear-gradient(135deg, #064e3b, #047857, #10b981);

    font-family: "Segoe UI", Arial, sans-serif;
    padding: 20px;
}

/* KARTU LOGIN */
.login-card {
    width: 100%;
    max-width: 410px;

    background: #ffffff;
    padding: 38px 32px;

    border-radius: 20px;

    box-shadow: 0 20px 50px rgba(0,0,0,0.25);

    animation: muncul 0.7s ease;
}

@keyframes muncul {
    from {
        opacity: 0;
        transform: translateY(25px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* LOGO */
.logo {
    width: 65px;
    height: 65px;

    margin: 0 auto 15px;

    display: flex;
    align-items: center;
    justify-content: center;

    background: linear-gradient(135deg, #047857, #10b981);
    color: white;

    border-radius: 18px;
    font-size: 30px;

    box-shadow: 0 5px 15px rgba(16,185,129,0.3);
}

/* JUDUL */
.login-card h1 {
    text-align: center;
    font-size: 23px;
    color: #065f46;
    font-weight: 800;
    letter-spacing: 0.5px;
}

.sub {
    text-align: center;
    color: #64748b;
    font-size: 13px;
    margin: 8px 0 28px;
}

/* LABEL */
.login-card label {
    display: block;
    color: #334155;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 8px;
}

/* INPUT */
.input-group {
    margin-bottom: 20px;
}

.login-card input {
    width: 100%;
    padding: 13px 15px;

    border: 1px solid #d1d5db;
    border-radius: 10px;

    font-size: 14px;
    background: #f8fafc;

    transition: 0.3s;
}

.login-card input:focus {
    outline: none;
    border-color: #059669;

    background: #ffffff;

    box-shadow: 0 0 0 4px rgba(5,150,105,0.12);
}

/* TOMBOL */
.login-card button {
    width: 100%;
    padding: 14px;

    border: none;
    border-radius: 10px;

    background: linear-gradient(120deg, #047857, #10b981);

    color: white;
    font-size: 15px;
    font-weight: 700;

    cursor: pointer;
    transition: 0.3s;
}

.login-card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 7px 18px rgba(5,150,105,0.3);
}

.login-card button:active {
    transform: scale(0.98);
}

/* ERROR */
.error {
    background: #fee2e2;
    color: #991b1b;

    border-left: 4px solid #dc2626;

    padding: 12px;
    border-radius: 8px;

    margin-bottom: 20px;
    font-size: 13px;
}

/* FOOTER */
.login-footer {
    text-align: center;
    color: #94a3b8;
    font-size: 12px;
    margin-top: 25px;
    line-height: 1.7;
}

/* RESPONSIVE */
@media (max-width: 480px) {
    .login-card {
        padding: 30px 22px;
    }

    .login-card h1 {
        font-size: 20px;
    }
}

</style>
</head>

<body>

<div class="login-card">

    <div class="logo">🎓</div>

    <h1>SMK MIFTAHUL KHAIR</h1>

    <p class="sub">
        Selamat Datang di SMK MIFTAHUL KHAIR
    </p>

    <?php if ($error): ?>
        <div class="error">
            ⚠ <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">

        <div class="input-group">
            <label for="username">Username</label>

            <input
                type="text"
                id="username"
                name="username"
                placeholder="Masukkan username Anda"
                required
                autofocus
            >
        </div>

        <div class="input-group">
            <label for="password">Password</label>

            <input
                type="password"
                id="password"
                name="password"
                placeholder="Masukkan password Anda"
                required
            >
        </div>

        <button type="submit">
            Login Disini Brayy →
        </button>

    </form>

    <div class="login-footer">
        © <?= date('Y') ?> SMK Miftahul Khair
        <br>
        Sistem Informasi SMK
    </div>

</div>

</body>
</html>
